# Persistencia local (Room/SQLite) y ranking online (Firebase)

Documentación de los puntos 4 y 5 de la consigna. Todo sigue la arquitectura MVVM de la app.

## 1. Qué se guarda y para qué (Room / SQLite)

Archivo de base de datos: `guerra_de_platillos.db` (Room 2.8, versión de esquema 1; el esquema se exporta a `app/schemas/`).

```mermaid
erDiagram
    partida_en_curso ||--o{ contienda : "tiene 3 (CASCADE)"
    partida_en_curso {
        int id PK "siempre 1: una sola partida en curso"
        text jugador
        long semilla "semilla del mezclado del mazo"
        text fase "COLOCACION | REVELACION"
        int contiendaActual "0..2"
        int segundosRestantes "cuenta regresiva al guardar"
        long iniciadaEn
        long actualizadaEn
        int versionFormato
    }
    contienda {
        int partidaId PK,FK
        int numero PK "0..2"
        text cartaJugadorId
        text cartaMaquinaId
        text resultado "JUGADOR | MAQUINA | EMPATE | NULL"
        int puntos
    }
    historial_partida {
        long id PK "autogenerado"
        text jugador
        int puntaje
        int contiendasGanadas
        int contiendasPerdidas
        int contiendasEmpatadas
        text resultado "VICTORIA | DERROTA | EMPATE"
        long jugadaEn
        bool sincronizada "false = pendiente de enviar al ranking"
    }
```

| Tabla | Contenido | Se usa para |
|---|---|---|
| `partida_en_curso` | Estado de la partida que el jugador dejó a medias (máximo 1 fila). | Botón **Continuar partida** del menú: retoma fase, contienda, timer y puntos aunque se cierre la app. |
| `contienda` | Las 3 contiendas de esa partida: ids de las cartas repartidas y, si ya se reveló, el resultado y los puntos. | Reconstruir exactamente el reparto de cartas y lo ya jugado. |
| `historial_partida` | Una fila por partida **terminada**. | Pantalla de resultados, estadísticas (partidas, victorias, mejor puntaje) y **cola de envío al ranking** (`sincronizada`). |

Decisiones de diseño:

- **Las cartas no se guardan, solo su `id`.** El catálogo vive en `CartaCatalog`; así se pueden ajustar los atributos sin migrar la base. Si una carta guardada ya no existe, la partida se descarta de forma segura (no hay crash ni botón "Continuar" roto).
- **Puntaje y victorias no se guardan en `partida_en_curso`: se derivan** de las contiendas, para que nunca haya datos inconsistentes.
- **Una sola partida en curso** (PK fija = 1). Empezar una partida nueva reemplaza la anterior (`@Upsert`, no `REPLACE`, porque `REPLACE` borraría las contiendas por la cascada).
- **Escrituras atómicas** (`@Transaction`): guardar partida + contiendas, y terminar una partida (insertar en historial + borrar la partida en curso) son operaciones de todo-o-nada.
- Enums guardados como texto (legible al inspeccionar la base con App Inspection).

## 2. Cómo se integra con MVVM

```
View (Compose)            ViewModel                    Model / Data
─────────────────────────────────────────────────────────────────────────────
MainMenuScreen   ───────► MainMenuViewModel ─────────► GameRepository ─► PartidaEnCursoDao ─► Room
GameScreen       ───────► GameViewModel     ─────────► GameRepository ─► PartidaEnCursoDao / HistorialDao
                              │                               ▲
                              └── GameEngine (reglas puras) ──┘   (model/)
GameOverScreen   ───────► GameOverViewModel ─► GameRepository + RankingRepository
RankingScreen    ───────► RankingViewModel  ─► RankingRepository ─► Firestore (+ cola en Room)
```

- **Model**: `model/` (`Carta`, `Partida`, `GameEngine`, reglas sin dependencias de Android), `data/local/` (entidades, DAOs, `AppDatabase`, mappers), `data/GameRepository`, `data/remote/RankingRepository`.
- **ViewModel**: dueño del estado (`StateFlow<Partida?>`), de la cuenta regresiva y de cuándo guardar.
- **View**: solo observa estado y delega acciones. Los repositorios se crean en `GuerraDePlatillosApp` (inyección manual, igual que el resto del proyecto).

### Operaciones (DAO)

`PartidaEnCursoDao`: `guardar` (transacción: upsert partida + contiendas), `obtener` (partida con sus contiendas, una sola consulta con `@Relation`), `observarHayPartida` (`Flow<Boolean>`), `descartar`.
`HistorialDao`: `insertar`, `obtener`, `observarUltimas`, `observarEstadisticas` (COUNT/SUM/MAX), `pendientesDeSincronizar`, `marcarSincronizada`, `observarCantidadPendientes`.

### Cuándo se guarda la partida (ciclo de vida)

| Momento | Acción |
|---|---|
| Cambia la fase (colocación → revelación → siguiente contienda) | Se guarda. |
| `ON_STOP` (app a segundo plano, llamada, pantalla bloqueada) o botón *volver* | Se frena el timer y se guarda (así no se pierden los segundos restantes si el sistema mata el proceso). |
| `ON_START` (la app vuelve) | El timer continúa donde estaba. |
| Se termina la 3.ª contienda | En una transacción: se inserta en `historial_partida` y se borra `partida_en_curso`. |
| Menú → **Continuar partida** | `GameViewModel` carga de Room (`continuar=true`). |
| Menú → **Nueva partida** | Se crea una partida y se sobrescribe la guardada. |

Las escrituras corren en `NonCancellable` y se serializan con un `Mutex`, para que salir de la pantalla no las corte y se apliquen en orden.

## 3. Reglas de puntaje (criterio del ranking)

- Contienda ganada: **100 + diferencia de poder** entre las cartas (poder = energía + saciedad + vitalidad).
- Empate: **50**. Contienda perdida: **0**.
- Puntaje de la partida = suma de las 3 contiendas. Máximo teórico 1200 (lo valida `firestore.rules`).
- El ranking ordena por **mejor puntaje** (descendente); desempate: menos partidas jugadas.

## 4. Ranking con Firebase (Cloud Firestore)

Colección `ranking`, un documento por jugador, **id = uid de Firebase Auth anónimo** (el jugador no necesita contraseña; se identifica por su nombre/seudónimo):

```
ranking/{uid} = { uid, alias, mejorPuntaje, partidasJugadas, victorias, actualizado (server timestamp) }
```

Flujo de registro de un resultado real:

1. Al terminar la partida se guarda en Room con `sincronizada = false`.
2. `GameOverViewModel` llama a `RankingRepository.sincronizarPendientes()`: inicia sesión anónima (si hace falta) y, por cada partida pendiente, corre una **transacción** que conserva el mejor puntaje y suma partidas/victorias; luego marca la fila como `sincronizada = true`.
3. `RankingViewModel` muestra el top 50 **en tiempo real** (`addSnapshotListener`), ordenado por `mejorPuntaje` descendente.

### Errores de conexión

| Situación | Comportamiento |
|---|---|
| Sin internet al terminar la partida | El resultado queda en Room como pendiente; la pantalla de resultados lo informa y ofrece **Reintentar envío**. Se reintenta solo al abrir el ranking. |
| Sin internet al abrir el ranking | Si hay datos en caché se muestran con un aviso ("Sin conexión…"); si no, mensaje de error + **Reintentar**. |
| Tiempo de espera | Toda operación tiene timeout de 15 s (`withTimeout`) y se trata como "sin conexión". |
| Reglas rechazan la operación | Mensaje específico (`PERMISO_DENEGADO`). |
| Falta `google-services.json` o Auth anónima deshabilitada | Mensaje "ranking no configurado"; la app y el juego siguen funcionando. |

La app nunca se cae por un error de red: `RankingError` / `ResultadoSync` convierten las excepciones en estados que la UI muestra.

### Reglas de seguridad (`firestore.rules`)

- Solo usuarios autenticados (anónimos) pueden leer.
- Cada jugador solo crea/actualiza **su** documento (`uid == request.auth.uid`).
- Se validan: campos permitidos, alias de 2 a 20 caracteres, puntaje entero entre 0 y 1200, contadores coherentes, `actualizado == request.time`.
- El mejor puntaje **no puede bajar**; `partidasJugadas` avanza de a 1; no se puede borrar; el resto de colecciones está cerrado.

> Limitación honesta: las reglas impiden escribir en el documento de otro jugador y valores imposibles, pero un cliente modificado podría enviar un puntaje alto válido para *su propio* documento. Evitarlo del todo requiere validar la partida en el servidor (Cloud Functions), fuera del alcance de la consigna.

## 5. Configurar Firebase (cada integrante, sin subir credenciales)

1. En [Firebase Console](https://console.firebase.google.com) crear un proyecto (o usar el del grupo) y agregar una app Android con el paquete `com.daa.guerradeplatillos`.
2. **Build → Authentication → Sign-in method → Anónimo → Habilitar.**
3. **Build → Firestore Database → Crear base de datos.**
4. Pegar el contenido de `firestore.rules` en la pestaña *Rules* y publicar (o `firebase deploy --only firestore:rules`).
5. Descargar `google-services.json` y guardarlo en **`app/google-services.json`**. Está en `.gitignore`: **no lo subas al repositorio**. Se incluye `app/google-services.json.example` solo como plantilla sin datos reales.
6. Compilar. Sin ese archivo la app compila igual y el ranking muestra "no configurado".

## 6. Pruebas

- `app/src/test/.../GameEngineTest.kt` (JUnit, 11 casos): reparto, timer, resolución de contiendas, puntajes, fin de partida y que el puntaje máximo respeta el límite de las reglas de Firestore.
- `app/src/androidTest/.../GameRepositoryTest.kt` (instrumentada, Room en memoria): guardar/cargar, reemplazo, finalizar partida (historial + borrado atómico), cola de sincronización, descarte de guardados corruptos y borrado en cascada.

Prueba manual sugerida para la presentación: jugar una contienda → cerrar la app desde recientes → abrirla → **Continuar partida**; jugar en modo avión → ver "pendiente" → reconectar → abrir **Ranking**.
