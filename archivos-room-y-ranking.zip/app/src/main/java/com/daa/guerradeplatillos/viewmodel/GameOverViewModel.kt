package com.daa.guerradeplatillos.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.daa.guerradeplatillos.GuerraDePlatillosApp
import com.daa.guerradeplatillos.data.local.PartidaHistorialEntity
import com.daa.guerradeplatillos.data.remote.RankingError
import com.daa.guerradeplatillos.data.remote.ResultadoSync
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Estado del envío del resultado al ranking online. */
enum class EstadoEnvio { ENVIANDO, ENVIADO, SIN_CONEXION, SIN_CONFIGURAR, ERROR }

/**
 * ViewModel de la pantalla de resultados: lee la partida recién terminada desde Room
 * (argumento `id`) y la envía al ranking. Si falla, queda pendiente en Room y se reintenta.
 */
class GameOverViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle,
) : AndroidViewModel(application) {

    private val app = application as GuerraDePlatillosApp
    private val historialId: Long = savedStateHandle.get<Long>("id") ?: -1L

    private val _partida = MutableStateFlow<PartidaHistorialEntity?>(null)
    val partida: StateFlow<PartidaHistorialEntity?> = _partida.asStateFlow()

    private val _envio = MutableStateFlow(EstadoEnvio.ENVIANDO)
    val envio: StateFlow<EstadoEnvio> = _envio.asStateFlow()

    init {
        viewModelScope.launch { _partida.value = app.gameRepository.obtenerPartidaTerminada(historialId) }
        enviar()
    }

    fun reintentarEnvio() = enviar()

    private fun enviar() {
        _envio.value = EstadoEnvio.ENVIANDO
        viewModelScope.launch {
            // NonCancellable: si el jugador sale de la pantalla a mitad del envío no se corta
            // entre "se escribió en Firebase" y "se marcó como sincronizada en Room".
            val resultado = withContext(NonCancellable) { app.rankingRepository.sincronizarPendientes() }
            _envio.value = when (resultado) {
                is ResultadoSync.NadaPendiente, is ResultadoSync.Enviados -> EstadoEnvio.ENVIADO
                is ResultadoSync.Fallo -> when (resultado.error) {
                    RankingError.SIN_CONEXION -> EstadoEnvio.SIN_CONEXION
                    RankingError.SIN_CONFIGURAR -> EstadoEnvio.SIN_CONFIGURAR
                    else -> EstadoEnvio.ERROR
                }
            }
        }
    }
}
