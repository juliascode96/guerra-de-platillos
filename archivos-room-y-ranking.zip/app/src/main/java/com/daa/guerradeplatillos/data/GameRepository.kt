package com.daa.guerradeplatillos.data

import androidx.room.withTransaction
import com.daa.guerradeplatillos.data.local.AppDatabase
import com.daa.guerradeplatillos.data.local.EstadisticasJugador
import com.daa.guerradeplatillos.data.local.PartidaHistorialEntity
import com.daa.guerradeplatillos.data.local.contiendasToEntities
import com.daa.guerradeplatillos.data.local.toDomain
import com.daa.guerradeplatillos.data.local.toEntity
import com.daa.guerradeplatillos.data.local.toHistorial
import com.daa.guerradeplatillos.model.Partida
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow

/**
 * Única puerta de entrada a los datos locales de juego (patrón Repository del MVVM).
 * Los ViewModels hablan con esta clase con objetos de dominio ([Partida]) y no conocen
 * entidades, DAOs ni SQL.
 */
class GameRepository(private val db: AppDatabase) {

    private val partidaDao = db.partidaEnCursoDao()
    private val historialDao = db.historialDao()

    // ---------- Partida en curso ----------

    /** `true` mientras exista una partida guardada para retomar. */
    val hayPartidaGuardada: Flow<Boolean> = partidaDao.observarHayPartida()

    /**
     * Devuelve la partida guardada o `null` si no hay / está corrupta o es incompatible
     * (en ese caso se descarta para no dejar al jugador con un botón "Continuar" roto).
     */
    suspend fun cargarPartida(): Partida? {
        val filas = try {
            partidaDao.obtener()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Por ejemplo un valor de enum que ya no existe tras actualizar la app.
            partidaDao.descartar()
            return null
        } ?: return null

        val partida = filas.toDomain()
        if (partida == null) partidaDao.descartar()
        return partida
    }

    /** Guarda (crea o actualiza) la partida en curso, atómicamente. */
    suspend fun guardarPartida(partida: Partida) {
        partidaDao.guardar(partida.toEntity(), partida.contiendasToEntities())
    }

    suspend fun descartarPartida() = partidaDao.descartar()

    /**
     * Cierra la partida: inserta el resultado en el historial y borra la partida en curso
     * en UNA transacción (si la app muere en el medio no se duplica ni se pierde nada).
     * @return id de la fila de historial creada.
     */
    suspend fun finalizarPartida(partida: Partida): Long = db.withTransaction {
        val id = historialDao.insertar(partida.toHistorial())
        partidaDao.descartar()
        id
    }

    // ---------- Historial y estadísticas ----------

    suspend fun obtenerPartidaTerminada(id: Long): PartidaHistorialEntity? = historialDao.obtener(id)

    fun observarHistorial(limite: Int = 20): Flow<List<PartidaHistorialEntity>> =
        historialDao.observarUltimas(limite)

    fun observarEstadisticas(): Flow<EstadisticasJugador> = historialDao.observarEstadisticas()
}
