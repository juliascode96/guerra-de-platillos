package com.daa.guerradeplatillos.model

/**
 * Catálogo de cartas del mazo.
 *
 * IMPORTANTE: los valores son de EJEMPLO para poder probar el guardado de partida.
 * Reemplazar por el catálogo definitivo del equipo. Lo único que importa a la persistencia
 * es que cada carta tenga un [Carta.id] ESTABLE: si un id desaparece, una partida guardada
 * que lo use se descarta de forma segura (ver GameRepository.cargarPartida).
 */
object CartaCatalog {

    val all: List<Carta> = listOf(
        // Héroes (alimentos sanos)
        Carta("brocoli", "Brócoli", TipoCarta.SANA, energia = 70, saciedad = 80, vitalidad = 95),
        Carta("lentejas", "Lentejas", TipoCarta.SANA, energia = 85, saciedad = 90, vitalidad = 80),
        Carta("palta", "Palta", TipoCarta.SANA, energia = 80, saciedad = 85, vitalidad = 85),
        Carta("banana", "Banana", TipoCarta.SANA, energia = 85, saciedad = 65, vitalidad = 75),
        Carta("avena", "Avena", TipoCarta.SANA, energia = 90, saciedad = 85, vitalidad = 70),
        Carta("huevo", "Huevo", TipoCarta.SANA, energia = 75, saciedad = 90, vitalidad = 80),
        // Villanos (ultraprocesados)
        Carta("gaseosa", "Gaseosa", TipoCarta.PROCESADA, energia = 60, saciedad = 10, vitalidad = 5),
        Carta("papas_fritas", "Papas fritas de bolsa", TipoCarta.PROCESADA, energia = 55, saciedad = 30, vitalidad = 15),
        Carta("chizitos", "Snack de queso", TipoCarta.PROCESADA, energia = 50, saciedad = 25, vitalidad = 10),
        Carta("salchicha", "Salchicha industrial", TipoCarta.PROCESADA, energia = 45, saciedad = 45, vitalidad = 20),
        Carta("golosinas", "Golosinas", TipoCarta.PROCESADA, energia = 65, saciedad = 5, vitalidad = 0),
        Carta("galletitas", "Galletitas rellenas", TipoCarta.PROCESADA, energia = 60, saciedad = 25, vitalidad = 10),
    )

    private val porId: Map<String, Carta> = all.associateBy { it.id }

    fun byId(id: String): Carta? = porId[id]
}
