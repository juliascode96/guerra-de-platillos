package com.daa.guerradeplatillos.data.remote

/** Una fila del ranking compartido (documento `ranking/{uid}` en Firestore). */
data class RankingEntry(
    val uid: String,
    val alias: String,
    val mejorPuntaje: Int,
    val partidasJugadas: Int,
    val victorias: Int,
)

/** Causas de error que la UI sabe explicar al jugador. */
enum class RankingError {
    /** Falta `google-services.json` (la app corre sin Firebase) o la auth anónima está deshabilitada. */
    SIN_CONFIGURAR,

    /** Sin internet, servidor inalcanzable o tiempo de espera agotado. */
    SIN_CONEXION,

    /** Las reglas de seguridad rechazaron la operación. */
    PERMISO_DENEGADO,

    DESCONOCIDO,
}

/** Estados posibles de la pantalla de ranking. */
sealed interface RankingEstado {
    data object Cargando : RankingEstado

    /**
     * @param desdeCache `true` si los datos vienen de la caché local (sin confirmar con el servidor).
     * @param miUid uid anónimo del jugador, para resaltar su fila.
     */
    data class Datos(
        val entradas: List<RankingEntry>,
        val desdeCache: Boolean,
        val miUid: String?,
    ) : RankingEstado

    data class Error(val tipo: RankingError) : RankingEstado
}

/** Resultado de intentar enviar al ranking las partidas pendientes del historial local. */
sealed interface ResultadoSync {
    data object NadaPendiente : ResultadoSync
    data class Enviados(val cantidad: Int) : ResultadoSync
    data class Fallo(val error: RankingError, val enviados: Int) : ResultadoSync
}
