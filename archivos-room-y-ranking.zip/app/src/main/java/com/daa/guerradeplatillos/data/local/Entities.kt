package com.daa.guerradeplatillos.data.local

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation
import com.daa.guerradeplatillos.model.FasePartida
import com.daa.guerradeplatillos.model.ResultadoContienda
import com.daa.guerradeplatillos.model.ResultadoPartida

/**
 * Tabla `partida_en_curso`: la partida que el jugador dejó a medias.
 *
 * Hay UNA sola fila como máximo (PK fija = [SLOT_UNICO]): empezar una partida nueva
 * sobrescribe la anterior y terminar una partida borra la fila. Así "¿hay partida para
 * continuar?" es simplemente "¿existe la fila?".
 *
 * Los enums se guardan como TEXT con el nombre del valor (Room lo hace solo).
 */
@Entity(tableName = "partida_en_curso")
data class PartidaEnCursoEntity(
    @PrimaryKey val id: Int = SLOT_UNICO,
    /** Nombre/seudónimo del jugador al momento de empezar. */
    val jugador: String,
    /** Semilla con la que se mezcló el mazo (permite reconstruir/depurar el reparto). */
    val semilla: Long,
    val fase: FasePartida,
    /** Índice 0..2 de la contienda en juego. */
    val contiendaActual: Int,
    /** Segundos que faltaban de la cuenta regresiva al guardar. */
    val segundosRestantes: Int,
    /** Epoch millis en que se creó la partida. */
    val iniciadaEn: Long,
    /** Epoch millis del último guardado. */
    val actualizadaEn: Long,
    /** Versión del formato de guardado; permite descartar guardados incompatibles. */
    val versionFormato: Int = VERSION_FORMATO,
) {
    companion object {
        const val SLOT_UNICO = 1
        const val VERSION_FORMATO = 1
    }
}

/**
 * Tabla `contienda`: las 3 contiendas de la partida en curso (hijas de `partida_en_curso`).
 *
 * El reparto de cartas se decide al empezar, por eso las 3 filas existen desde el comienzo;
 * `resultado` es NULL hasta que la contienda se revela. Se guardan solo los ids de carta
 * (el catálogo vive en código). ON DELETE CASCADE: al descartar la partida se borran solas.
 */
@Entity(
    tableName = "contienda",
    primaryKeys = ["partidaId", "numero"],
    foreignKeys = [
        ForeignKey(
            entity = PartidaEnCursoEntity::class,
            parentColumns = ["id"],
            childColumns = ["partidaId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
)
data class ContiendaEntity(
    val partidaId: Int = PartidaEnCursoEntity.SLOT_UNICO,
    /** 0..2 */
    val numero: Int,
    val cartaJugadorId: String,
    val cartaMaquinaId: String,
    val resultado: ResultadoContienda?,
    val puntos: Int,
)

/** Partida en curso + sus contiendas, cargadas juntas con una sola consulta. */
data class PartidaConContiendas(
    @Embedded val partida: PartidaEnCursoEntity,
    @Relation(parentColumn = "id", entityColumn = "partidaId")
    val contiendas: List<ContiendaEntity>,
)

/**
 * Tabla `historial_partida`: una fila por partida TERMINADA.
 *
 * Se usa para: pantalla de resultados, historial/estadísticas del perfil, mejor puntaje
 * personal y como COLA DE ENVÍO al ranking de Firebase: `sincronizada = 0` significa que el
 * resultado todavía no llegó al servidor (p. ej. se jugó sin conexión) y se reintentará.
 */
@Entity(
    tableName = "historial_partida",
    indices = [Index("jugadaEn"), Index("sincronizada")],
)
data class PartidaHistorialEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val jugador: String,
    val puntaje: Int,
    val contiendasGanadas: Int,
    val contiendasPerdidas: Int,
    val contiendasEmpatadas: Int,
    val resultado: ResultadoPartida,
    /** Epoch millis en que terminó la partida. */
    val jugadaEn: Long,
    /** `true` cuando el resultado ya fue registrado en el ranking online. */
    val sincronizada: Boolean = false,
)

/** Estadísticas agregadas del historial (resultado de una consulta con COUNT/SUM/MAX). */
data class EstadisticasJugador(
    val partidas: Int,
    val victorias: Int,
    val mejorPuntaje: Int,
)
