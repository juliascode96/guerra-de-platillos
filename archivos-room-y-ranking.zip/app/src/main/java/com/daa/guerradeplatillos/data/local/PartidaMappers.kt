package com.daa.guerradeplatillos.data.local

import com.daa.guerradeplatillos.model.CartaCatalog
import com.daa.guerradeplatillos.model.Contienda
import com.daa.guerradeplatillos.model.GameEngine
import com.daa.guerradeplatillos.model.Partida

/** Dominio → filas de Room. */
fun Partida.toEntity(ahora: Long = System.currentTimeMillis()): PartidaEnCursoEntity =
    PartidaEnCursoEntity(
        jugador = jugador,
        semilla = semilla,
        fase = fase,
        contiendaActual = contiendaActual,
        segundosRestantes = segundosRestantes,
        iniciadaEn = iniciadaEn,
        actualizadaEn = ahora,
    )

fun Partida.contiendasToEntities(): List<ContiendaEntity> = contiendas.map {
    ContiendaEntity(
        numero = it.numero,
        cartaJugadorId = it.cartaJugador.id,
        cartaMaquinaId = it.cartaMaquina.id,
        resultado = it.resultado,
        puntos = it.puntos,
    )
}

/**
 * Filas de Room → dominio.
 * Devuelve `null` si el guardado no se puede reconstruir (formato viejo, carta que ya no
 * existe en el catálogo, datos fuera de rango): el repositorio lo trata como "no hay partida".
 */
fun PartidaConContiendas.toDomain(): Partida? {
    if (partida.versionFormato != PartidaEnCursoEntity.VERSION_FORMATO) return null
    if (contiendas.size != GameEngine.TOTAL_CONTIENDAS) return null
    if (partida.contiendaActual !in 0 until GameEngine.TOTAL_CONTIENDAS) return null

    val reconstruidas = contiendas.sortedBy { it.numero }.map { fila ->
        val jugador = CartaCatalog.byId(fila.cartaJugadorId) ?: return null
        val maquina = CartaCatalog.byId(fila.cartaMaquinaId) ?: return null
        Contienda(
            numero = fila.numero,
            cartaJugador = jugador,
            cartaMaquina = maquina,
            resultado = fila.resultado,
            puntos = fila.puntos,
        )
    }
    if (reconstruidas.map { it.numero } != (0 until GameEngine.TOTAL_CONTIENDAS).toList()) return null

    return Partida(
        jugador = partida.jugador,
        semilla = partida.semilla,
        contiendas = reconstruidas,
        contiendaActual = partida.contiendaActual,
        fase = partida.fase,
        segundosRestantes = partida.segundosRestantes.coerceIn(0, GameEngine.SEGUNDOS_COLOCACION),
        iniciadaEn = partida.iniciadaEn,
    )
}

/** Partida terminada → fila de historial (pendiente de sincronizar con el ranking). */
fun Partida.toHistorial(ahora: Long = System.currentTimeMillis()): PartidaHistorialEntity =
    PartidaHistorialEntity(
        jugador = jugador,
        puntaje = puntaje,
        contiendasGanadas = victoriasJugador,
        contiendasPerdidas = victoriasMaquina,
        contiendasEmpatadas = empates,
        resultado = GameEngine.resultadoFinal(this),
        jugadaEn = ahora,
        sincronizada = false,
    )

