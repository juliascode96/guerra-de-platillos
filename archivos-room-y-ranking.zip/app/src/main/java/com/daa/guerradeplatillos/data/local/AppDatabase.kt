package com.daa.guerradeplatillos.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Base de datos local (Room sobre SQLite): archivo `guerra_de_platillos.db`.
 *
 * Al cambiar entidades hay que subir [version] y agregar una Migration en [crear];
 * NO usar fallbackToDestructiveMigration, porque borraría la partida guardada y el historial.
 */
@Database(
    entities = [
        PartidaEnCursoEntity::class,
        ContiendaEntity::class,
        PartidaHistorialEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun partidaEnCursoDao(): PartidaEnCursoDao
    abstract fun historialDao(): HistorialDao

    companion object {
        const val NOMBRE = "guerra_de_platillos.db"

        fun crear(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, NOMBRE)
                .build()
    }
}
