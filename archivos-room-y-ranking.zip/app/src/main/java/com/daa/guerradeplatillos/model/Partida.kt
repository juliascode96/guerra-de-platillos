package com.daa.guerradeplatillos.model

/** Fase en la que está la partida (README: colocación boca abajo → revelación). */
enum class FasePartida {
    /** Cartas boca abajo sobre el mantel, con cuenta regresiva. */
    COLOCACION,

    /** Cartas reveladas; se muestra quién ganó la contienda. */
    REVELACION,

    /** Se jugaron las 3 contiendas. Es un estado transitorio: nunca queda guardado como "en curso". */
    FINALIZADA,
}

enum class ResultadoContienda { JUGADOR, MAQUINA, EMPATE }

enum class ResultadoPartida { VICTORIA, DERROTA, EMPATE }

/**
 * Una contienda (turno): una carta del jugador contra una de la máquina.
 * [resultado] es `null` hasta que las cartas se revelan.
 */
data class Contienda(
    val numero: Int,
    val cartaJugador: Carta,
    val cartaMaquina: Carta,
    val resultado: ResultadoContienda? = null,
    val puntos: Int = 0,
) {
    val revelada: Boolean get() = resultado != null
}

/**
 * Estado completo e inmutable de una partida (una "mano" de 3 contiendas).
 * Es lo que el ViewModel expone a la UI y lo que Room guarda para poder retomarla.
 *
 * Todo lo que se puede calcular (puntaje, victorias) se DERIVA de [contiendas] en lugar
 * de guardarse aparte, para que nunca queden datos inconsistentes.
 */
data class Partida(
    val jugador: String,
    val semilla: Long,
    val contiendas: List<Contienda>,
    val contiendaActual: Int,
    val fase: FasePartida,
    val segundosRestantes: Int,
    val iniciadaEn: Long,
) {
    val contiendaEnJuego: Contienda get() = contiendas[contiendaActual]

    val victoriasJugador: Int get() = contiendas.count { it.resultado == ResultadoContienda.JUGADOR }
    val victoriasMaquina: Int get() = contiendas.count { it.resultado == ResultadoContienda.MAQUINA }
    val empates: Int get() = contiendas.count { it.resultado == ResultadoContienda.EMPATE }

    /** Puntaje acumulado: es el valor que se registra en el historial y en el ranking. */
    val puntaje: Int get() = contiendas.sumOf { it.puntos }

    /** El botón / gesto de revelar solo se habilita cuando terminó la cuenta regresiva. */
    val puedeRevelar: Boolean get() = fase == FasePartida.COLOCACION && segundosRestantes == 0
}
