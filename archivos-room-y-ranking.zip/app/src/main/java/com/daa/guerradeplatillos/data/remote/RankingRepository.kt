package com.daa.guerradeplatillos.data.remote

import android.content.Context
import com.daa.guerradeplatillos.data.local.HistorialDao
import com.daa.guerradeplatillos.data.local.PartidaHistorialEntity
import com.daa.guerradeplatillos.model.ResultadoPartida
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.Transaction
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout

/**
 * Ranking compartido sobre Cloud Firestore.
 *
 * Modelo de datos: colección `ranking`, un documento por jugador con id = uid de Firebase
 * Auth (sesión anónima, sin pedir contraseña):
 *   { uid, alias, mejorPuntaje, partidasJugadas, victorias, actualizado }
 * Criterio de orden: `mejorPuntaje` descendente.
 *
 * Los resultados se registran desde el historial local de Room (tabla `historial_partida`,
 * columna `sincronizada`): si no hay conexión, el resultado queda pendiente y se reenvía
 * en el próximo intento. Las reglas de seguridad están en `firestore.rules`.
 */
class RankingRepository(
    private val context: Context,
    private val historialDao: HistorialDao,
) {
    private val syncMutex = Mutex()

    /** `false` si el proyecto se compiló sin `google-services.json`. */
    val firebaseDisponible: Boolean
        get() = FirebaseApp.getApps(context).isNotEmpty()

    fun observarPendientes(): Flow<Int> = historialDao.observarCantidadPendientes()

    // ---------------------------------------------------------------- lectura

    /**
     * Ranking en tiempo real (top [limite]). Emite [RankingEstado.Cargando], luego
     * [RankingEstado.Datos] en cada cambio, o [RankingEstado.Error] y se completa.
     * Para reintentar basta con volver a recolectar el flujo.
     */
    fun observarRanking(limite: Int = 50): Flow<RankingEstado> = callbackFlow {
        if (!firebaseDisponible) {
            trySend(RankingEstado.Error(RankingError.SIN_CONFIGURAR))
            close()
            return@callbackFlow
        }
        trySend(RankingEstado.Cargando)

        val uid = try {
            asegurarSesion()
        } catch (e: TimeoutCancellationException) {
            trySend(RankingEstado.Error(RankingError.SIN_CONEXION)); close(); return@callbackFlow
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            trySend(RankingEstado.Error(e.aRankingError())); close(); return@callbackFlow
        }

        val registro = FirebaseFirestore.getInstance()
            .collection(COLECCION)
            .orderBy(CAMPO_PUNTAJE, Query.Direction.DESCENDING)
            .limit(limite.toLong())
            .addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
                if (error != null) {
                    trySend(RankingEstado.Error(error.aRankingError()))
                    close()
                    return@addSnapshotListener
                }
                if (snapshot == null) return@addSnapshotListener
                val entradas = snapshot.documents.mapNotNull { doc ->
                    val alias = doc.getString("alias") ?: return@mapNotNull null
                    RankingEntry(
                        uid = doc.id,
                        alias = alias,
                        mejorPuntaje = doc.getLong(CAMPO_PUNTAJE)?.toInt() ?: 0,
                        partidasJugadas = doc.getLong("partidasJugadas")?.toInt() ?: 0,
                        victorias = doc.getLong("victorias")?.toInt() ?: 0,
                    )
                    // Desempate: a igual puntaje, queda arriba quien lo logró en menos partidas.
                }.sortedWith(compareByDescending<RankingEntry> { it.mejorPuntaje }.thenBy { it.partidasJugadas })

                trySend(RankingEstado.Datos(entradas, snapshot.metadata.isFromCache, uid))
            }
        awaitClose { registro.remove() }
    }

    // --------------------------------------------------------------- escritura

    /**
     * Envía al ranking todas las partidas pendientes del historial local, de la más vieja a
     * la más nueva. Se detiene en el primer error (el resto sigue pendiente) y NUNCA lanza
     * excepciones de red: devuelve un [ResultadoSync] que la UI puede mostrar.
     */
    suspend fun sincronizarPendientes(): ResultadoSync = syncMutex.withLock {
        val pendientes = historialDao.pendientesDeSincronizar()
        if (pendientes.isEmpty()) return ResultadoSync.NadaPendiente
        if (!firebaseDisponible) return ResultadoSync.Fallo(RankingError.SIN_CONFIGURAR, 0)

        var enviados = 0
        try {
            val uid = asegurarSesion()
            for (partida in pendientes) {
                publicarResultado(uid, partida)
                historialDao.marcarSincronizada(partida.id)
                enviados++
            }
            ResultadoSync.Enviados(enviados)
        } catch (e: TimeoutCancellationException) {
            ResultadoSync.Fallo(RankingError.SIN_CONEXION, enviados)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ResultadoSync.Fallo(e.aRankingError(), enviados)
        }
    }

    /**
     * Actualiza el documento del jugador en una transacción (leer → decidir → escribir):
     * conserva el mejor puntaje y suma partidas/victorias. Offline la transacción falla con
     * UNAVAILABLE y la partida queda pendiente en Room.
     */
    private suspend fun publicarResultado(uid: String, partida: PartidaHistorialEntity) {
        val firestore = FirebaseFirestore.getInstance()
        val ref = firestore.collection(COLECCION).document(uid)
        val esVictoria = partida.resultado == ResultadoPartida.VICTORIA

        withTimeout(TIMEOUT_MS) {
            firestore.runTransaction(Transaction.Function<Void?> { tx ->
                val previo = tx.get(ref)
                val mejorPrevio = previo.getLong(CAMPO_PUNTAJE) ?: 0L
                val partidasPrevias = previo.getLong("partidasJugadas") ?: 0L
                val victoriasPrevias = previo.getLong("victorias") ?: 0L

                tx.set(
                    ref,
                    mapOf(
                        "uid" to uid,
                        "alias" to partida.jugador,
                        CAMPO_PUNTAJE to maxOf(mejorPrevio, partida.puntaje.toLong()),
                        "partidasJugadas" to partidasPrevias + 1,
                        "victorias" to victoriasPrevias + if (esVictoria) 1 else 0,
                        "actualizado" to FieldValue.serverTimestamp(),
                    ),
                )
                null
            }).await()
        }
    }

    // ------------------------------------------------------------------ auth

    /** Devuelve el uid de la sesión anónima, creándola la primera vez (requiere internet). */
    private suspend fun asegurarSesion(): String = withTimeout(TIMEOUT_MS) {
        val auth = FirebaseAuth.getInstance()
        auth.currentUser?.uid
            ?: auth.signInAnonymously().await().user?.uid
            ?: throw IllegalStateException("La autenticación anónima no devolvió usuario")
    }

    private companion object {
        const val COLECCION = "ranking"
        const val CAMPO_PUNTAJE = "mejorPuntaje"
        const val TIMEOUT_MS = 15_000L
    }
}

/** Traduce excepciones de Firebase/red a un error que la UI puede explicar. */
internal fun Throwable.aRankingError(): RankingError = when (this) {
    is FirebaseNetworkException -> RankingError.SIN_CONEXION
    is FirebaseFirestoreException -> when (code) {
        FirebaseFirestoreException.Code.UNAVAILABLE,
        FirebaseFirestoreException.Code.DEADLINE_EXCEEDED,
        -> RankingError.SIN_CONEXION

        FirebaseFirestoreException.Code.PERMISSION_DENIED,
        FirebaseFirestoreException.Code.UNAUTHENTICATED,
        -> RankingError.PERMISO_DENEGADO

        else -> RankingError.DESCONOCIDO
    }
    // Auth anónima deshabilitada en la consola, API key restringida, etc.
    is FirebaseAuthException -> RankingError.SIN_CONFIGURAR
    else -> RankingError.DESCONOCIDO
}
