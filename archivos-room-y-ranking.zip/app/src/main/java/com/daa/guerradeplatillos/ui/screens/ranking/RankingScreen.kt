package com.daa.guerradeplatillos.ui.screens.ranking

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.daa.guerradeplatillos.R
import com.daa.guerradeplatillos.data.remote.RankingEntry
import com.daa.guerradeplatillos.data.remote.RankingError
import com.daa.guerradeplatillos.data.remote.RankingEstado
import com.daa.guerradeplatillos.ui.components.AppCard
import com.daa.guerradeplatillos.ui.components.CircleIconButton
import com.daa.guerradeplatillos.ui.components.ScreenContainer
import com.daa.guerradeplatillos.ui.components.SecondaryButton
import com.daa.guerradeplatillos.ui.theme.AppTheme
import com.daa.guerradeplatillos.ui.theme.GuerraDePlatillosTheme
import com.daa.guerradeplatillos.viewmodel.RankingViewModel

/**
 * Pantalla de Ranking: tabla compartida (Firebase) ordenada por mejor puntaje, con
 * estados de carga, vacío, datos en caché (sin conexión) y error con "Reintentar".
 */
@Composable
fun RankingScreen(
    onBack: () -> Unit,
    onSettingsClick: () -> Unit,
    viewModel: RankingViewModel = viewModel(),
) {
    val estado by viewModel.estado.collectAsStateWithLifecycle()
    val pendientes by viewModel.pendientes.collectAsStateWithLifecycle()
    RankingContent(
        estado = estado,
        pendientes = pendientes,
        onBack = onBack,
        onSettingsClick = onSettingsClick,
        onRetry = viewModel::reintentar,
    )
}

@Composable
private fun RankingContent(
    estado: RankingEstado,
    pendientes: Int,
    onBack: () -> Unit,
    onSettingsClick: () -> Unit,
    onRetry: () -> Unit,
) {
    val colors = AppTheme.colors

    ScreenContainer {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header: volver + título + ruedita de opciones
            Box(modifier = Modifier.fillMaxWidth()) {
                CircleIconButton(
                    icon = R.drawable.ic_arrow_back,
                    contentDescription = stringResource(R.string.btn_back_description),
                    onClick = onBack,
                    modifier = Modifier.align(Alignment.CenterStart)
                )
                Text(
                    text = stringResource(R.string.ranking_title),
                    style = MaterialTheme.typography.headlineMedium,
                    fontSize = 20.sp,
                    color = colors.textPrimary,
                    modifier = Modifier.align(Alignment.Center)
                )
                CircleIconButton(
                    icon = R.drawable.ic_settings,
                    contentDescription = stringResource(R.string.btn_settings_description),
                    onClick = onSettingsClick,
                    modifier = Modifier.align(Alignment.CenterEnd)
                )
            }

            Spacer(Modifier.height(12.dp))

            if (pendientes > 0) {
                Banner(stringResource(R.string.ranking_pending, pendientes))
            }

            when (estado) {
                RankingEstado.Cargando -> Centrado {
                    Text(
                        text = stringResource(R.string.ranking_loading),
                        style = MaterialTheme.typography.bodyLarge,
                        color = colors.textSecondary,
                    )
                }

                is RankingEstado.Error -> Centrado {
                    Text(
                        text = estado.tipo.mensaje(),
                        style = MaterialTheme.typography.bodyLarge,
                        color = colors.textSecondary,
                        textAlign = TextAlign.Center,
                    )
                    // Sin configurar no se arregla reintentando.
                    if (estado.tipo != RankingError.SIN_CONFIGURAR) {
                        Spacer(Modifier.height(16.dp))
                        SecondaryButton(
                            text = stringResource(R.string.ranking_retry),
                            onClick = onRetry,
                            modifier = Modifier.height(48.dp),
                        )
                    }
                }

                is RankingEstado.Datos -> {
                    if (estado.desdeCache) Banner(stringResource(R.string.ranking_cache_banner))
                    if (estado.entradas.isEmpty()) {
                        Centrado {
                            Text(
                                text = stringResource(R.string.ranking_empty),
                                style = MaterialTheme.typography.bodyLarge,
                                color = colors.textSecondary,
                                textAlign = TextAlign.Center,
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            itemsIndexed(estado.entradas, key = { _, e -> e.uid }) { indice, entrada ->
                                FilaRanking(
                                    posicion = indice + 1,
                                    entrada = entrada,
                                    esMia = entrada.uid == estado.miUid,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.Centrado(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        content = content,
    )
}

@Composable
private fun Banner(texto: String) {
    Text(
        text = texto,
        color = AppTheme.colors.warning,
        fontSize = 12.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
    )
}

@Composable
private fun FilaRanking(posicion: Int, entrada: RankingEntry, esMia: Boolean) {
    val colors = AppTheme.colors
    AppCard(
        modifier = Modifier.fillMaxWidth(),
        selected = esMia,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "$posicion",
                color = if (posicion <= 3) colors.textHighlight else colors.textSecondary,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier.width(36.dp),
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (esMia) "${entrada.alias} ${stringResource(R.string.ranking_you)}" else entrada.alias,
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = stringResource(R.string.ranking_row_stats, entrada.partidasJugadas, entrada.victorias),
                    color = colors.textSecondary,
                    fontSize = 12.sp,
                )
            }
            Text(
                text = stringResource(R.string.ranking_points, entrada.mejorPuntaje),
                color = colors.textHighlight,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
private fun RankingError.mensaje(): String = stringResource(
    when (this) {
        RankingError.SIN_CONFIGURAR -> R.string.ranking_error_unconfigured
        RankingError.SIN_CONEXION -> R.string.ranking_error_offline
        RankingError.PERMISO_DENEGADO -> R.string.ranking_error_permission
        RankingError.DESCONOCIDO -> R.string.ranking_error_unknown
    }
)

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun RankingScreenPreview() {
    GuerraDePlatillosTheme {
        RankingContent(
            estado = RankingEstado.Datos(
                entradas = listOf(
                    RankingEntry("a", "Mateo", 980, 5, 4),
                    RankingEntry("b", "Lucía", 720, 3, 2),
                ),
                desdeCache = true,
                miUid = "b",
            ),
            pendientes = 1,
            onBack = {}, onSettingsClick = {}, onRetry = {},
        )
    }
}
