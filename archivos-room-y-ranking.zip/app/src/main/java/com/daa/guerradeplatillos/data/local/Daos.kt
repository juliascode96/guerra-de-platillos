package com.daa.guerradeplatillos.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

/**
 * Acceso a la partida en curso.
 *
 * Usamos @Upsert (INSERT o UPDATE) y NO @Insert(REPLACE) a propósito: REPLACE borra la fila
 * padre y, por el ON DELETE CASCADE, también borraría las contiendas.
 */
@Dao
abstract class PartidaEnCursoDao {

    @Upsert
    abstract suspend fun upsertPartida(partida: PartidaEnCursoEntity)

    @Upsert
    abstract suspend fun upsertContiendas(contiendas: List<ContiendaEntity>)

    /** Guarda partida + contiendas de forma atómica: o se guarda todo o nada. */
    @Transaction
    open suspend fun guardar(partida: PartidaEnCursoEntity, contiendas: List<ContiendaEntity>) {
        upsertPartida(partida)
        upsertContiendas(contiendas)
    }

    @Transaction
    @Query("SELECT * FROM partida_en_curso WHERE id = ${PartidaEnCursoEntity.SLOT_UNICO}")
    abstract suspend fun obtener(): PartidaConContiendas?

    /** Emite `true`/`false` cada vez que se crea o se borra la partida guardada. */
    @Query("SELECT EXISTS(SELECT 1 FROM partida_en_curso)")
    abstract fun observarHayPartida(): Flow<Boolean>

    /** Borra la partida en curso (las contiendas se eliminan en cascada). */
    @Query("DELETE FROM partida_en_curso")
    abstract suspend fun descartar()
}

/** Acceso al historial de partidas terminadas. */
@Dao
interface HistorialDao {

    @Insert
    suspend fun insertar(partida: PartidaHistorialEntity): Long

    @Query("SELECT * FROM historial_partida WHERE id = :id")
    suspend fun obtener(id: Long): PartidaHistorialEntity?

    @Query("SELECT * FROM historial_partida ORDER BY jugadaEn DESC LIMIT :limite")
    fun observarUltimas(limite: Int): Flow<List<PartidaHistorialEntity>>

    @Query(
        """
        SELECT COUNT(*) AS partidas,
               COALESCE(SUM(CASE WHEN resultado = 'VICTORIA' THEN 1 ELSE 0 END), 0) AS victorias,
               COALESCE(MAX(puntaje), 0) AS mejorPuntaje
        FROM historial_partida
        """
    )
    fun observarEstadisticas(): Flow<EstadisticasJugador>

    // ---- Cola de sincronización con el ranking ----

    @Query("SELECT * FROM historial_partida WHERE sincronizada = 0 ORDER BY jugadaEn ASC")
    suspend fun pendientesDeSincronizar(): List<PartidaHistorialEntity>

    @Query("SELECT COUNT(*) FROM historial_partida WHERE sincronizada = 0")
    fun observarCantidadPendientes(): Flow<Int>

    @Query("UPDATE historial_partida SET sincronizada = 1 WHERE id = :id")
    suspend fun marcarSincronizada(id: Long)

    @Query("DELETE FROM historial_partida")
    suspend fun borrarTodo()
}
