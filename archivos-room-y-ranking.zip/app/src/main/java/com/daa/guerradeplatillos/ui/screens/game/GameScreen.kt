package com.daa.guerradeplatillos.ui.screens.game

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.daa.guerradeplatillos.R
import com.daa.guerradeplatillos.model.Carta
import com.daa.guerradeplatillos.model.FasePartida
import com.daa.guerradeplatillos.model.GameEngine
import com.daa.guerradeplatillos.model.Partida
import com.daa.guerradeplatillos.model.ResultadoContienda
import com.daa.guerradeplatillos.model.TipoCarta
import com.daa.guerradeplatillos.ui.components.AppCard
import com.daa.guerradeplatillos.ui.components.BadgePill
import com.daa.guerradeplatillos.ui.components.CircleIconButton
import com.daa.guerradeplatillos.ui.components.PrimaryButton
import com.daa.guerradeplatillos.ui.components.ScreenContainer
import com.daa.guerradeplatillos.ui.theme.AppTheme
import com.daa.guerradeplatillos.ui.theme.GuerraDePlatillosTheme
import com.daa.guerradeplatillos.viewmodel.GameEvento
import com.daa.guerradeplatillos.viewmodel.GameViewModel

/**
 * Pantalla de juego (View). No tiene lógica: observa el estado del [GameViewModel] y le
 * delega las acciones. El ViewModel recibe el argumento de navegación `continuar`.
 *
 * Ciclo de vida: al pasar a segundo plano (ON_STOP) se pausa el timer y se guarda la
 * partida en Room; al volver (ON_START) la cuenta regresiva continúa donde estaba.
 */
@Composable
fun GameScreen(
    onBack: () -> Unit,
    onFinishGame: (historialId: Long) -> Unit,
    onSettingsClick: () -> Unit,
    viewModel: GameViewModel = viewModel(),
) {
    val partida by viewModel.partida.collectAsStateWithLifecycle()

    LifecycleEventEffect(Lifecycle.Event.ON_START) { viewModel.alVolverAPrimerPlano() }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { viewModel.alIrASegundoPlano() }

    LaunchedEffect(viewModel) {
        viewModel.eventos.collect { evento ->
            when (evento) {
                is GameEvento.Finalizada -> onFinishGame(evento.historialId)
            }
        }
    }

    GameContent(
        partida = partida,
        onBack = {
            viewModel.alIrASegundoPlano() // guarda antes de salir: la partida queda "en curso"
            onBack()
        },
        onSettingsClick = onSettingsClick,
        onReveal = viewModel::revelar,
        onNext = viewModel::siguiente,
    )
}

@Composable
private fun GameContent(
    partida: Partida?,
    onBack: () -> Unit,
    onSettingsClick: () -> Unit,
    onReveal: () -> Unit,
    onNext: () -> Unit,
) {
    val colors = AppTheme.colors

    ScreenContainer {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header: volver + título + ruedita de opciones
            Box(modifier = Modifier.fillMaxWidth()) {
                CircleIconButton(
                    icon = R.drawable.ic_arrow_back,
                    contentDescription = stringResource(R.string.btn_back_description),
                    onClick = onBack,
                    modifier = Modifier.align(Alignment.CenterStart)
                )
                Text(
                    text = stringResource(R.string.game_title),
                    style = MaterialTheme.typography.headlineMedium,
                    fontSize = 20.sp,
                    color = colors.textPrimary,
                    modifier = Modifier.align(Alignment.Center)
                )
                CircleIconButton(
                    icon = R.drawable.ic_settings,
                    contentDescription = stringResource(R.string.btn_settings_description),
                    onClick = onSettingsClick,
                    modifier = Modifier.align(Alignment.CenterEnd)
                )
            }

            if (partida == null) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text(
                        text = stringResource(R.string.game_loading),
                        style = MaterialTheme.typography.bodyLarge,
                        color = colors.textSecondary,
                    )
                }
                return@Column
            }

            val contienda = partida.contiendaEnJuego
            val reveladas = partida.fase != FasePartida.COLOCACION

            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BadgePill(
                    text = stringResource(
                        R.string.game_round_counter,
                        partida.contiendaActual + 1,
                        GameEngine.TOTAL_CONTIENDAS,
                    )
                )
                BadgePill(text = stringResource(R.string.game_score, partida.puntaje))
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CartaView(
                    titulo = stringResource(R.string.game_you),
                    carta = contienda.cartaJugador,
                    bocaArriba = reveladas,
                    destacada = contienda.resultado == ResultadoContienda.JUGADOR,
                    modifier = Modifier.weight(1f),
                )
                CartaView(
                    titulo = stringResource(R.string.game_machine),
                    carta = contienda.cartaMaquina,
                    bocaArriba = reveladas,
                    destacada = contienda.resultado == ResultadoContienda.MAQUINA,
                    modifier = Modifier.weight(1f),
                )
            }

            Text(
                text = estadoTexto(partida),
                style = MaterialTheme.typography.bodyLarge,
                color = colors.textHighlight,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))

            val esUltima = partida.contiendaActual == GameEngine.TOTAL_CONTIENDAS - 1
            when (partida.fase) {
                FasePartida.COLOCACION -> PrimaryButton(
                    text = stringResource(R.string.game_btn_reveal),
                    onClick = onReveal,
                    enabled = partida.puedeRevelar,
                    modifier = Modifier.fillMaxWidth(),
                )
                else -> PrimaryButton(
                    text = stringResource(if (esUltima) R.string.game_btn_results else R.string.game_btn_next),
                    onClick = onNext,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.game_autosave_hint),
                color = colors.textSecondary,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun estadoTexto(partida: Partida): String {
    val contienda = partida.contiendaEnJuego
    return when {
        partida.fase == FasePartida.COLOCACION && partida.segundosRestantes > 0 ->
            stringResource(R.string.game_status_countdown, partida.segundosRestantes)
        partida.fase == FasePartida.COLOCACION -> stringResource(R.string.game_status_ready)
        contienda.resultado == ResultadoContienda.JUGADOR -> stringResource(R.string.game_status_win, contienda.puntos)
        contienda.resultado == ResultadoContienda.EMPATE -> stringResource(R.string.game_status_tie, contienda.puntos)
        else -> stringResource(R.string.game_status_lose)
    }
}

/** Carta boca abajo ("?") o boca arriba con sus tres atributos. */
@Composable
private fun CartaView(
    titulo: String,
    carta: Carta,
    bocaArriba: Boolean,
    destacada: Boolean,
    modifier: Modifier = Modifier,
) {
    val colors = AppTheme.colors
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = titulo,
            color = colors.textSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(8.dp))
        AppCard(modifier = Modifier.fillMaxWidth().heightIn(min = 220.dp), selected = destacada) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (bocaArriba) {
                    Text(if (carta.tipo == TipoCarta.SANA) "🥦" else "🧟", fontSize = 40.sp)
                    Text(
                        text = carta.nombre,
                        color = colors.textPrimary,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                    )
                    Text(stringResource(R.string.game_attr_energy, carta.energia), color = colors.textSecondary, fontSize = 13.sp)
                    Text(stringResource(R.string.game_attr_satiety, carta.saciedad), color = colors.textSecondary, fontSize = 13.sp)
                    Text(stringResource(R.string.game_attr_vitality, carta.vitalidad), color = colors.textSecondary, fontSize = 13.sp)
                } else {
                    Spacer(Modifier.height(60.dp))
                    Text(
                        text = stringResource(R.string.game_card_hidden),
                        color = colors.textHighlight,
                        fontSize = 56.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun GameScreenPreview() {
    GuerraDePlatillosTheme {
        GameContent(
            partida = GameEngine.nuevaPartida("Preview", semilla = 1L),
            onBack = {}, onSettingsClick = {}, onReveal = {}, onNext = {},
        )
    }
}
