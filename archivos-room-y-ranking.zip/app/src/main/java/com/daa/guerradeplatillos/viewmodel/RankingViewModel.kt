package com.daa.guerradeplatillos.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.daa.guerradeplatillos.GuerraDePlatillosApp
import com.daa.guerradeplatillos.data.remote.RankingEstado
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * ViewModel del ranking: expone la tabla en tiempo real y la cantidad de resultados locales
 * que todavía no se pudieron enviar. Al abrirse (y en cada reintento) intenta enviar los
 * pendientes del historial de Room.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class RankingViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = (application as GuerraDePlatillosApp).rankingRepository

    private val intento = MutableStateFlow(0)

    /** Cada vez que cambia [intento] se vuelve a suscribir al ranking (reintento tras un error). */
    val estado: StateFlow<RankingEstado> = intento
        .flatMapLatest { repo.observarRanking() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RankingEstado.Cargando)

    val pendientes: StateFlow<Int> = repo.observarPendientes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    init {
        enviarPendientes()
    }

    fun reintentar() {
        intento.update { it + 1 }
        enviarPendientes()
    }

    private fun enviarPendientes() {
        viewModelScope.launch { withContext(NonCancellable) { repo.sincronizarPendientes() } }
    }
}
