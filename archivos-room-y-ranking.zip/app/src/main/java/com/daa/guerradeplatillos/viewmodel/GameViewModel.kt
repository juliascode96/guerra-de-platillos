package com.daa.guerradeplatillos.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.daa.guerradeplatillos.GuerraDePlatillosApp
import com.daa.guerradeplatillos.model.FasePartida
import com.daa.guerradeplatillos.model.GameEngine
import com.daa.guerradeplatillos.model.Partida
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** Eventos de una sola vez que la pantalla debe atender (navegación). */
sealed interface GameEvento {
    /** La partida terminó y quedó guardada en el historial con ese id. */
    data class Finalizada(val historialId: Long) : GameEvento
}

/**
 * ViewModel del juego: dueño del estado de la [Partida] y de la cuenta regresiva.
 *
 * Persistencia (Room, vía [com.daa.guerradeplatillos.data.GameRepository]):
 *  - Se guarda en cada cambio de fase (colocación → revelación → siguiente contienda).
 *  - Se guarda al pasar a segundo plano ([alIrASegundoPlano]) para no perder los segundos
 *    restantes del timer si el sistema mata la app.
 *  - Al terminar, la partida pasa al historial y se borra la partida en curso.
 *
 * Argumento de navegación `continuar`: `true` retoma la partida guardada; `false` arranca
 * una nueva (reemplazando la guardada).
 */
class GameViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle,
) : AndroidViewModel(application) {

    private val app = application as GuerraDePlatillosApp
    private val repo = app.gameRepository

    private val _partida = MutableStateFlow<Partida?>(null)
    val partida: StateFlow<Partida?> = _partida.asStateFlow()

    private val _eventos = Channel<GameEvento>(Channel.BUFFERED)
    val eventos: Flow<GameEvento> = _eventos.receiveAsFlow()

    private var timerJob: Job? = null
    private var finalizando = false

    /** Serializa las escrituras para que se apliquen en el mismo orden en que se pidieron. */
    private val guardadoMutex = Mutex()

    init {
        val continuar = savedStateHandle.get<Boolean>(ARG_CONTINUAR) ?: false
        viewModelScope.launch {
            val guardada = if (continuar) repo.cargarPartida() else null
            val inicial = guardada ?: GameEngine.nuevaPartida(
                jugador = app.userRepository.avatar.value?.nombre?.takeIf { it.isNotBlank() } ?: "Jugador",
            )
            _partida.value = inicial
            if (guardada == null) persistir(inicial)
            arrancarTimer()
        }
    }

    // ------------------------------------------------------------ acciones de juego

    /** Da vuelta las cartas. También es el punto de entrada para el gesto de agitar (sensor). */
    fun revelar() = avanzar(GameEngine::revelar)

    fun siguiente() = avanzar(GameEngine::siguiente)

    private fun avanzar(transicion: (Partida) -> Partida) {
        val actual = _partida.value ?: return
        if (finalizando) return
        val nueva = transicion(actual)
        if (nueva == actual) return
        _partida.value = nueva
        when (nueva.fase) {
            FasePartida.FINALIZADA -> finalizar(nueva)
            FasePartida.COLOCACION -> { persistir(nueva); arrancarTimer() }
            FasePartida.REVELACION -> persistir(nueva)
        }
    }

    // ------------------------------------------------------------ ciclo de vida

    /** Llamar desde ON_STOP (y al salir con "volver"): frena el timer y guarda. */
    fun alIrASegundoPlano() {
        timerJob?.cancel()
        val actual = _partida.value ?: return
        if (!finalizando && actual.fase != FasePartida.FINALIZADA) persistir(actual)
    }

    /** Llamar desde ON_START: retoma la cuenta regresiva donde quedó. */
    fun alVolverAPrimerPlano() = arrancarTimer()

    // ------------------------------------------------------------ internos

    private fun arrancarTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                val p = _partida.value ?: return@launch
                if (p.fase != FasePartida.COLOCACION || p.segundosRestantes == 0) return@launch
                delay(1_000)
                _partida.value = _partida.value?.let(GameEngine::tick)
            }
        }
    }

    /**
     * Guarda en Room sin que se corte si el ViewModel se destruye justo después
     * (por ejemplo al tocar "volver"): la escritura corre en NonCancellable.
     */
    private fun persistir(partida: Partida) {
        viewModelScope.launch {
            try {
                withContext(NonCancellable) { guardadoMutex.withLock { repo.guardarPartida(partida) } }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "No se pudo guardar la partida en curso", e)
            }
        }
    }

    private fun finalizar(partida: Partida) {
        finalizando = true
        timerJob?.cancel()
        viewModelScope.launch {
            try {
                val id = withContext(NonCancellable) { guardadoMutex.withLock { repo.finalizarPartida(partida) } }
                _eventos.send(GameEvento.Finalizada(id))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "No se pudo registrar la partida terminada", e)
                finalizando = false
            }
        }
    }

    companion object {
        const val ARG_CONTINUAR = "continuar"
        private const val TAG = "GameViewModel"
    }
}
