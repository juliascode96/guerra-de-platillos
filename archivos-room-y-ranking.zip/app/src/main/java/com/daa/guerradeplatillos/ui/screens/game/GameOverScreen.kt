package com.daa.guerradeplatillos.ui.screens.game

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.daa.guerradeplatillos.R
import com.daa.guerradeplatillos.data.local.PartidaHistorialEntity
import com.daa.guerradeplatillos.model.ResultadoPartida
import com.daa.guerradeplatillos.ui.components.CircleIconButton
import com.daa.guerradeplatillos.ui.components.PrimaryButton
import com.daa.guerradeplatillos.ui.components.ScreenContainer
import com.daa.guerradeplatillos.ui.components.SecondaryButton
import com.daa.guerradeplatillos.ui.theme.AppTheme
import com.daa.guerradeplatillos.ui.theme.GuerraDePlatillosTheme
import com.daa.guerradeplatillos.viewmodel.EstadoEnvio
import com.daa.guerradeplatillos.viewmodel.GameOverViewModel

/**
 * Pantalla de Fin de Juego: muestra el resultado leído de Room (historial) y el estado
 * del envío al ranking online.
 */
@Composable
fun GameOverScreen(
    onPlayAgain: () -> Unit,
    onBackToMenu: () -> Unit,
    onSettingsClick: () -> Unit,
    viewModel: GameOverViewModel = viewModel(),
) {
    val partida by viewModel.partida.collectAsStateWithLifecycle()
    val envio by viewModel.envio.collectAsStateWithLifecycle()
    GameOverContent(
        partida = partida,
        envio = envio,
        onPlayAgain = onPlayAgain,
        onBackToMenu = onBackToMenu,
        onSettingsClick = onSettingsClick,
        onRetrySync = viewModel::reintentarEnvio,
    )
}

@Composable
private fun GameOverContent(
    partida: PartidaHistorialEntity?,
    envio: EstadoEnvio,
    onPlayAgain: () -> Unit,
    onBackToMenu: () -> Unit,
    onSettingsClick: () -> Unit,
    onRetrySync: () -> Unit,
) {
    val colors = AppTheme.colors

    ScreenContainer {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header: volver al menú + título + ruedita de opciones
            Box(modifier = Modifier.fillMaxWidth()) {
                CircleIconButton(
                    icon = R.drawable.ic_arrow_back,
                    contentDescription = stringResource(R.string.btn_back_description),
                    onClick = onBackToMenu,
                    modifier = Modifier.align(Alignment.CenterStart)
                )
                Text(
                    text = stringResource(R.string.game_over_title),
                    style = MaterialTheme.typography.headlineMedium,
                    fontSize = 20.sp,
                    color = colors.textPrimary,
                    modifier = Modifier.align(Alignment.Center)
                )
                CircleIconButton(
                    icon = R.drawable.ic_settings,
                    contentDescription = stringResource(R.string.btn_settings_description),
                    onClick = onSettingsClick,
                    modifier = Modifier.align(Alignment.CenterEnd)
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                if (partida == null) {
                    Text(
                        text = stringResource(R.string.game_over_loading),
                        style = MaterialTheme.typography.bodyLarge,
                        color = colors.textSecondary,
                    )
                } else {
                    Text(
                        text = stringResource(
                            when (partida.resultado) {
                                ResultadoPartida.VICTORIA -> R.string.game_over_victory
                                ResultadoPartida.DERROTA -> R.string.game_over_defeat
                                ResultadoPartida.EMPATE -> R.string.game_over_draw
                            }
                        ),
                        style = MaterialTheme.typography.headlineMedium,
                        color = colors.textHighlight,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.game_over_score, partida.puntaje),
                        style = MaterialTheme.typography.headlineMedium,
                        color = colors.textPrimary,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.game_over_player, partida.jugador),
                        color = colors.textSecondary,
                    )
                    Text(
                        text = stringResource(
                            R.string.game_over_rounds,
                            partida.contiendasGanadas,
                            partida.contiendasPerdidas,
                            partida.contiendasEmpatadas,
                        ),
                        color = colors.textSecondary,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(24.dp))
                    Text(
                        text = stringResource(
                            when (envio) {
                                EstadoEnvio.ENVIANDO -> R.string.sync_sending
                                EstadoEnvio.ENVIADO -> R.string.sync_done
                                EstadoEnvio.SIN_CONEXION -> R.string.sync_offline
                                EstadoEnvio.SIN_CONFIGURAR -> R.string.sync_unconfigured
                                EstadoEnvio.ERROR -> R.string.sync_error
                            }
                        ),
                        color = if (envio == EstadoEnvio.ENVIADO) colors.success else colors.warning,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                    )
                    if (envio == EstadoEnvio.SIN_CONEXION || envio == EstadoEnvio.ERROR) {
                        Spacer(Modifier.height(8.dp))
                        SecondaryButton(
                            text = stringResource(R.string.sync_retry),
                            onClick = onRetrySync,
                            modifier = Modifier.height(48.dp),
                        )
                    }
                }
            }

            PrimaryButton(
                text = stringResource(R.string.game_over_play_again),
                onClick = onPlayAgain,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            SecondaryButton(
                text = stringResource(R.string.game_over_back_menu),
                onClick = onBackToMenu,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            )
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun GameOverScreenPreview() {
    GuerraDePlatillosTheme {
        GameOverContent(
            partida = PartidaHistorialEntity(
                id = 1, jugador = "Mateo", puntaje = 640, contiendasGanadas = 2,
                contiendasPerdidas = 1, contiendasEmpatadas = 0,
                resultado = ResultadoPartida.VICTORIA, jugadaEn = 0L,
            ),
            envio = EstadoEnvio.SIN_CONEXION,
            onPlayAgain = {}, onBackToMenu = {}, onSettingsClick = {}, onRetrySync = {},
        )
    }
}
