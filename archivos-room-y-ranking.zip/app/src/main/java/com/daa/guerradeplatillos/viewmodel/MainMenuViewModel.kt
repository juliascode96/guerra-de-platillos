package com.daa.guerradeplatillos.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.daa.guerradeplatillos.GuerraDePlatillosApp
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

/** ViewModel del menú: indica si hay una partida guardada para mostrar "Continuar". */
class MainMenuViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = (application as GuerraDePlatillosApp).gameRepository

    val hayPartidaGuardada: StateFlow<Boolean> = repo.hayPartidaGuardada
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)
}
