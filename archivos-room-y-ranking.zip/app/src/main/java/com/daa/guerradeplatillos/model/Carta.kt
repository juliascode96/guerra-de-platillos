package com.daa.guerradeplatillos.model

/** Bando al que pertenece una carta: alimentos sanos (héroes) o procesados (villanos). */
enum class TipoCarta { SANA, PROCESADA }

/**
 * Carta del juego. Los tres atributos nutricionales (0–100) definen quién gana la contienda.
 *
 * Las cartas NO se guardan en la base de datos: viven en [CartaCatalog] y la partida
 * guardada solo referencia su [id]. Así, ajustar los valores de una carta no obliga a migrar Room.
 */
data class Carta(
    val id: String,
    val nombre: String,
    val tipo: TipoCarta,
    val energia: Int,
    val saciedad: Int,
    val vitalidad: Int,
) {
    /** Balance total de la carta: es lo que se compara en cada contienda. */
    val poder: Int get() = energia + saciedad + vitalidad
}
