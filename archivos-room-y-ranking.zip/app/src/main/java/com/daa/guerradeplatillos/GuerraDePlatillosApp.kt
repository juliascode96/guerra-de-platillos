package com.daa.guerradeplatillos

import android.app.Application
import com.daa.guerradeplatillos.data.GameRepository
import com.daa.guerradeplatillos.data.SettingsRepository
import com.daa.guerradeplatillos.data.UserRepository
import com.daa.guerradeplatillos.data.local.AppDatabase
import com.daa.guerradeplatillos.data.remote.RankingRepository
import com.daa.guerradeplatillos.util.SoundManager

/**
 * Application: crea los repositorios compartidos (inyección manual simple)
 * y precarga los sonidos.
 */
class GuerraDePlatillosApp : Application() {

    lateinit var settingsRepository: SettingsRepository
        private set
    lateinit var userRepository: UserRepository
        private set

    /** Base de datos Room (se abre de forma perezosa en el primer acceso). */
    lateinit var database: AppDatabase
        private set

    /** Partida en curso, historial y estadísticas (Room). */
    lateinit var gameRepository: GameRepository
        private set

    /** Ranking compartido (Firebase) + cola de envío desde el historial de Room. */
    lateinit var rankingRepository: RankingRepository
        private set

    override fun onCreate() {
        super.onCreate()
        settingsRepository = SettingsRepository(this)
        userRepository = UserRepository(this)
        database = AppDatabase.crear(this)
        gameRepository = GameRepository(database)
        rankingRepository = RankingRepository(this, database.historialDao())
        SoundManager.init(this) { settingsRepository.soundEnabled.value }
    }
}
