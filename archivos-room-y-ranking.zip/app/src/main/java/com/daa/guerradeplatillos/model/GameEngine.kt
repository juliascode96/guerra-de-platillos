package com.daa.guerradeplatillos.model

import kotlin.random.Random

/**
 * Reglas del juego como funciones puras (sin Android, sin I/O): reciben una [Partida]
 * y devuelven la siguiente. Esto las hace trivialmente testeables y permite que el
 * ViewModel solo orqueste (timer, guardado, navegación).
 *
 * Criterio de puntaje (el mismo que usa el ranking):
 *  - Contienda ganada: [PUNTOS_VICTORIA] + diferencia de poder con la carta rival.
 *  - Contienda empatada: [PUNTOS_EMPATE].
 *  - Contienda perdida: 0.
 */
object GameEngine {
    const val TOTAL_CONTIENDAS = 3
    const val SEGUNDOS_COLOCACION = 5
    const val PUNTOS_VICTORIA = 100
    const val PUNTOS_EMPATE = 50

    /** Mezcla el mazo con [semilla] y reparte [TOTAL_CONTIENDAS] cartas a cada bando. */
    fun nuevaPartida(
        jugador: String,
        semilla: Long = Random.nextLong(),
        ahora: Long = System.currentTimeMillis(),
        catalogo: List<Carta> = CartaCatalog.all,
    ): Partida {
        require(catalogo.size >= TOTAL_CONTIENDAS * 2) { "El mazo necesita al menos ${TOTAL_CONTIENDAS * 2} cartas" }
        val mazo = catalogo.shuffled(Random(semilla))
        val contiendas = List(TOTAL_CONTIENDAS) { i ->
            Contienda(
                numero = i,
                cartaJugador = mazo[i],
                cartaMaquina = mazo[TOTAL_CONTIENDAS + i],
            )
        }
        return Partida(
            jugador = jugador,
            semilla = semilla,
            contiendas = contiendas,
            contiendaActual = 0,
            fase = FasePartida.COLOCACION,
            segundosRestantes = SEGUNDOS_COLOCACION,
            iniciadaEn = ahora,
        )
    }

    /** Avanza un segundo de la cuenta regresiva (solo en fase de colocación). */
    fun tick(partida: Partida): Partida =
        if (partida.fase == FasePartida.COLOCACION && partida.segundosRestantes > 0) {
            partida.copy(segundosRestantes = partida.segundosRestantes - 1)
        } else partida

    /** Da vuelta las cartas y resuelve la contienda. Ignorado si todavía no terminó el timer. */
    fun revelar(partida: Partida): Partida {
        if (!partida.puedeRevelar) return partida
        val actual = partida.contiendaEnJuego
        val resuelta = actual.copy(
            resultado = resolver(actual.cartaJugador, actual.cartaMaquina),
            puntos = puntosContienda(actual.cartaJugador, actual.cartaMaquina),
        )
        return partida.copy(
            contiendas = partida.contiendas.mapIndexed { i, c -> if (i == partida.contiendaActual) resuelta else c },
            fase = FasePartida.REVELACION,
        )
    }

    /** Pasa a la siguiente contienda o, si era la última, finaliza la partida. */
    fun siguiente(partida: Partida): Partida {
        if (partida.fase != FasePartida.REVELACION) return partida
        val proxima = partida.contiendaActual + 1
        return if (proxima >= TOTAL_CONTIENDAS) {
            partida.copy(fase = FasePartida.FINALIZADA)
        } else {
            partida.copy(
                contiendaActual = proxima,
                fase = FasePartida.COLOCACION,
                segundosRestantes = SEGUNDOS_COLOCACION,
            )
        }
    }

    fun resolver(jugador: Carta, maquina: Carta): ResultadoContienda = when {
        jugador.poder > maquina.poder -> ResultadoContienda.JUGADOR
        jugador.poder < maquina.poder -> ResultadoContienda.MAQUINA
        else -> ResultadoContienda.EMPATE
    }

    fun puntosContienda(jugador: Carta, maquina: Carta): Int = when (resolver(jugador, maquina)) {
        ResultadoContienda.JUGADOR -> PUNTOS_VICTORIA + (jugador.poder - maquina.poder)
        ResultadoContienda.EMPATE -> PUNTOS_EMPATE
        ResultadoContienda.MAQUINA -> 0
    }

    /** Resultado global de la mano: gana quien se lleve más contiendas. */
    fun resultadoFinal(partida: Partida): ResultadoPartida = when {
        partida.victoriasJugador > partida.victoriasMaquina -> ResultadoPartida.VICTORIA
        partida.victoriasJugador < partida.victoriasMaquina -> ResultadoPartida.DERROTA
        else -> ResultadoPartida.EMPATE
    }
}
