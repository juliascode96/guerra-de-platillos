package com.daa.guerradeplatillos.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GameEngineTest {

    private fun carta(id: String, poder: Int) =
        Carta(id, id, TipoCarta.SANA, energia = poder, saciedad = 0, vitalidad = 0)

    /** Partida con cartas fijas: el jugador siempre gana por 10 de diferencia. */
    private fun partidaGanadora(): Partida {
        val contiendas = List(3) { i ->
            Contienda(i, cartaJugador = carta("j$i", 60), cartaMaquina = carta("m$i", 50))
        }
        return Partida("Test", 1L, contiendas, 0, FasePartida.COLOCACION, 0, 0L)
    }

    @Test
    fun nuevaPartida_reparteTresCartasDistintasACadaBando() {
        val p = GameEngine.nuevaPartida("Mateo", semilla = 42L, ahora = 0L)
        assertEquals(3, p.contiendas.size)
        val ids = p.contiendas.flatMap { listOf(it.cartaJugador.id, it.cartaMaquina.id) }
        assertEquals(6, ids.toSet().size)
        assertEquals(FasePartida.COLOCACION, p.fase)
        assertEquals(GameEngine.SEGUNDOS_COLOCACION, p.segundosRestantes)
    }

    @Test
    fun nuevaPartida_mismaSemillaMismoReparto() {
        val a = GameEngine.nuevaPartida("A", semilla = 7L, ahora = 0L)
        val b = GameEngine.nuevaPartida("A", semilla = 7L, ahora = 0L)
        assertEquals(a, b)
        val c = GameEngine.nuevaPartida("A", semilla = 8L, ahora = 0L)
        assertNotEquals(a.contiendas, c.contiendas)
    }

    @Test
    fun tick_descuentaHastaCeroYNoPasaDeAhi() {
        var p = GameEngine.nuevaPartida("A", semilla = 1L, ahora = 0L)
        repeat(GameEngine.SEGUNDOS_COLOCACION + 3) { p = GameEngine.tick(p) }
        assertEquals(0, p.segundosRestantes)
        assertTrue(p.puedeRevelar)
    }

    @Test
    fun revelar_noHaceNadaAntesDeQueTermineElTimer() {
        val p = GameEngine.nuevaPartida("A", semilla = 1L, ahora = 0L)
        assertFalse(p.puedeRevelar)
        assertEquals(p, GameEngine.revelar(p))
    }

    @Test
    fun revelar_resuelveLaContiendaYSumaPuntos() {
        val p = GameEngine.revelar(partidaGanadora())
        assertEquals(FasePartida.REVELACION, p.fase)
        assertEquals(ResultadoContienda.JUGADOR, p.contiendas[0].resultado)
        assertEquals(GameEngine.PUNTOS_VICTORIA + 10, p.puntaje)
    }

    @Test
    fun empate_daPuntosDeEmpate() {
        val c = Contienda(0, carta("j", 50), carta("m", 50))
        val p = partidaGanadora().copy(contiendas = listOf(c, c.copy(numero = 1), c.copy(numero = 2)))
        val r = GameEngine.revelar(p)
        assertEquals(ResultadoContienda.EMPATE, r.contiendas[0].resultado)
        assertEquals(GameEngine.PUNTOS_EMPATE, r.puntaje)
    }

    @Test
    fun derrota_noSumaPuntos() {
        val c = Contienda(0, carta("j", 10), carta("m", 90))
        val p = partidaGanadora().copy(contiendas = listOf(c, c.copy(numero = 1), c.copy(numero = 2)))
        assertEquals(0, GameEngine.revelar(p).puntaje)
    }

    @Test
    fun partidaCompleta_terminaDespuesDeTresContiendas() {
        var p = partidaGanadora()
        repeat(GameEngine.TOTAL_CONTIENDAS) { i ->
            p = GameEngine.revelar(p)
            assertEquals(FasePartida.REVELACION, p.fase)
            p = GameEngine.siguiente(p)
            if (i < GameEngine.TOTAL_CONTIENDAS - 1) {
                assertEquals(FasePartida.COLOCACION, p.fase)
                assertEquals(i + 1, p.contiendaActual)
                assertEquals(GameEngine.SEGUNDOS_COLOCACION, p.segundosRestantes)
                p = p.copy(segundosRestantes = 0) // saltamos la espera para el test
            }
        }
        assertEquals(FasePartida.FINALIZADA, p.fase)
        assertEquals(3, p.victoriasJugador)
        assertEquals(ResultadoPartida.VICTORIA, GameEngine.resultadoFinal(p))
        assertEquals(3 * (GameEngine.PUNTOS_VICTORIA + 10), p.puntaje)
    }

    @Test
    fun siguiente_ignoradoSiNoSeRevelo() {
        val p = partidaGanadora()
        assertEquals(p, GameEngine.siguiente(p))
    }

    @Test
    fun puntajeMaximoPosible_noSuperaElLimiteDeLasReglasDeFirestore() {
        // firestore.rules acepta mejorPuntaje <= 1200. Peor caso con el catálogo actual:
        val mejores = CartaCatalog.all.sortedByDescending { it.poder }.take(3)
        val peores = CartaCatalog.all.sortedBy { it.poder }.take(3)
        val max = mejores.zip(peores).sumOf { (j, m) -> GameEngine.puntosContienda(j, m) }
        assertTrue("Máximo teórico $max supera 1200", max <= 1200)
    }

    @Test
    fun catalogo_idsUnicosYBusquedaPorId() {
        val ids = CartaCatalog.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        CartaCatalog.all.forEach { assertEquals(it, CartaCatalog.byId(it.id)) }
    }
}
