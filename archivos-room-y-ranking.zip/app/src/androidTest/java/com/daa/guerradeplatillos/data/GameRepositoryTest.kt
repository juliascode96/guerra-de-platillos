package com.daa.guerradeplatillos.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.daa.guerradeplatillos.data.local.AppDatabase
import com.daa.guerradeplatillos.data.local.PartidaEnCursoEntity
import com.daa.guerradeplatillos.model.FasePartida
import com.daa.guerradeplatillos.model.GameEngine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Prueba instrumentada de Room con una base en memoria (se ejecuta en un dispositivo/emulador). */
@RunWith(AndroidJUnit4::class)
class GameRepositoryTest {

    private lateinit var db: AppDatabase
    private lateinit var repo: GameRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).build()
        repo = GameRepository(db)
    }

    @After
    fun tearDown() = db.close()

    @Test
    fun sinGuardado_cargarDevuelveNullYNoHayPartida() = runBlocking {
        assertNull(repo.cargarPartida())
        assertFalse(repo.hayPartidaGuardada.first())
    }

    @Test
    fun guardarYCargar_devuelveLaMismaPartida() = runBlocking {
        var p = GameEngine.nuevaPartida("Mateo", semilla = 5L, ahora = 1_000L)
        p = p.copy(segundosRestantes = 0)
        p = GameEngine.revelar(p) // contienda 0 resuelta, fase REVELACION
        repo.guardarPartida(p)

        assertTrue(repo.hayPartidaGuardada.first())
        assertEquals(p, repo.cargarPartida())
    }

    @Test
    fun guardarDosVeces_actualizaSinPerderLasContiendas() = runBlocking {
        val p = GameEngine.nuevaPartida("Mateo", semilla = 5L, ahora = 1_000L)
        repo.guardarPartida(p)
        repo.guardarPartida(GameEngine.tick(p))

        val cargada = repo.cargarPartida()
        assertNotNull(cargada)
        assertEquals(GameEngine.TOTAL_CONTIENDAS, cargada!!.contiendas.size)
        assertEquals(GameEngine.SEGUNDOS_COLOCACION - 1, cargada.segundosRestantes)
    }

    @Test
    fun partidaNueva_reemplazaALaGuardada() = runBlocking {
        repo.guardarPartida(GameEngine.nuevaPartida("A", semilla = 1L, ahora = 1L))
        val nueva = GameEngine.nuevaPartida("B", semilla = 2L, ahora = 2L)
        repo.guardarPartida(nueva)
        assertEquals(nueva, repo.cargarPartida())
    }

    @Test
    fun finalizar_pasaAlHistorialYBorraLaPartidaEnCurso() = runBlocking {
        var p = GameEngine.nuevaPartida("Mateo", semilla = 3L, ahora = 1L)
        repo.guardarPartida(p)
        p = p.copy(fase = FasePartida.FINALIZADA)

        val id = repo.finalizarPartida(p)

        assertNull(repo.cargarPartida())
        assertFalse(repo.hayPartidaGuardada.first())
        val fila = repo.obtenerPartidaTerminada(id)
        assertNotNull(fila)
        assertEquals("Mateo", fila!!.jugador)
        assertFalse("Debe quedar pendiente de sincronizar", fila.sincronizada)
        assertEquals(1, repo.observarEstadisticas().first().partidas)
        // El DAO de historial ve la partida como pendiente de envío al ranking.
        assertEquals(1, db.historialDao().pendientesDeSincronizar().size)
    }

    @Test
    fun marcarSincronizada_laSacaDeLaColaDePendientes() = runBlocking {
        val id = repo.finalizarPartida(GameEngine.nuevaPartida("A", semilla = 1L, ahora = 1L))
        db.historialDao().marcarSincronizada(id)
        assertTrue(db.historialDao().pendientesDeSincronizar().isEmpty())
    }

    @Test
    fun guardadoCorrupto_seDescartaEnLugarDeRomperLaApp() = runBlocking {
        // Simula un guardado con una versión de formato que esta app ya no entiende.
        db.partidaEnCursoDao().guardar(
            PartidaEnCursoEntity(
                jugador = "X", semilla = 1L, fase = FasePartida.COLOCACION, contiendaActual = 0,
                segundosRestantes = 5, iniciadaEn = 0L, actualizadaEn = 0L, versionFormato = 999,
            ),
            emptyList(),
        )
        assertNull(repo.cargarPartida())
        assertFalse(repo.hayPartidaGuardada.first())
    }

    @Test
    fun descartarPartida_borraLasContiendasEnCascada() = runBlocking {
        repo.guardarPartida(GameEngine.nuevaPartida("A", semilla = 1L, ahora = 1L))
        repo.descartarPartida()
        val cursor = db.query("SELECT COUNT(*) FROM contienda", null)
        cursor.moveToFirst()
        assertEquals(0, cursor.getInt(0))
        cursor.close()
    }
}
